import React from 'react';
import logoImage from '../assets/Logo.png'; // Replace with your actual image path
import '../style/Header.css'; // Import the CSS file you created

function Header() {
  return (
    <header className="header">
      <div className="logo">
        <img src={logoImage} alt="Loop Movies Logo" />
        <h1>Loop Web</h1>
      </div>
    </header>
  );
}

export default Header;
