import React from "react";

export default function Footer() {
  const footerStyle = {
    backgroundColor: '#343a40',
    padding: '20px 0',
    color: 'white',
  };

  const footerContentStyle = {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
  };

  const footerTitleStyle = {
    marginBottom: '10px',
  };

  const contactListStyle = {
    listStyleType: 'none',
    padding: 0,
    display: 'flex',
    gap: '10px',
  };

  const contactLinkStyle = {
    color: 'white',
    textDecoration: 'none',
    transition: 'color 0.3s ease',
  };

  const footerInfoStyle = {
    marginTop: '10px',
    fontSize: '12px',
    textAlign: 'center',
  };

  return (
    <footer style={footerStyle}>
      <div style={footerContentStyle}>
        <h2 style={footerTitleStyle}>Contact Us</h2>
        <ul style={contactListStyle}>
          <li><a href="#" style={contactLinkStyle}>Email</a></li>
          <li><a href="#" style={contactLinkStyle}>Phone</a></li>
          <li><a href="#" style={contactLinkStyle}>Address</a></li>
        </ul>
      </div>
    </footer>
  );
}
