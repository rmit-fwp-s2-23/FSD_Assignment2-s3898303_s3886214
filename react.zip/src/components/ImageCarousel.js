import React from 'react';
import { Carousel } from 'react-responsive-carousel';
import 'react-responsive-carousel/lib/styles/carousel.min.css';
import '../style/ImageCarousel.css';

const ImageCarousel = () => {
  const movies = [
    {
      title: 'The Revenge of Spiderman',
      image: require('../assets/Spider.jpg'),
      description: 'In Theatres 17th of November 2023',
    },
    {
      title: 'Fire Wrecks a Forrest',
      image: require('../assets/Fire.jpg'),
      description: 'In Theatres 19th of November 2023',
    },
    {
      title: 'Love the Classic Way',
      image: require('../assets/Love.jpg'),
      description: 'In Theatres 21th of November 2023',
    },
  ];

  return (
    <div className="image-carousel-container">
      <Carousel
        showThumbs={false}
        showStatus={false}
        autoPlay={true}
        infiniteLoop={true}
        interval={2500}
        transitionTime={500}
        emulateTouch={true}
        swipeable={true}
      >
        {movies.map((movie, index) => (
          <div key={index} className="carousel-item">
            <img src={movie.image} alt={movie.title} />
            <div className="movie-details">
              <h3 className="movie-title">{movie.title}</h3>
              <p className="movie-description">{movie.description}</p>
            </div>
          </div>
        ))}
      </Carousel>
    </div>
  );
};

export default ImageCarousel;
