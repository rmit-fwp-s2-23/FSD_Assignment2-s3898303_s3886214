import React from 'react';
import { render, fireEvent, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect'; // For custom matchers like toHaveTextContent
import SignUp from './SignUp'; // Update the import path accordingly

// Mock the loginUser function and createUser function
const mockLoginUser = jest.fn();
const mockCreateUser = jest.fn();

jest.mock('../data/repository', () => ({
  createUser: (user) => mockCreateUser(user),
}));

describe('SignUp Component', () => {
  it('renders the SignUp form', () => {
    const { getByText, getByLabelText } = render(<SignUp loginUser={mockLoginUser} />);
    
    // Verify that the form elements are present
    expect(getByText('SignUp')).toBeInTheDocument();
    expect(getByLabelText('Name')).toBeInTheDocument();
    expect(getByLabelText('Email')).toBeInTheDocument();
    expect(getByLabelText('Password')).toBeInTheDocument();
    expect(getByLabelText('Confirm password')).toBeInTheDocument();
  });

  it('handles form submission and createUser', async () => {
    mockCreateUser.mockResolvedValueOnce({ email: 'test@example.com', name: 'Test User' });

    const { getByLabelText, getByText } = render(<SignUp loginUser={mockLoginUser} />);

    // Fill in the form fields
    fireEvent.change(getByLabelText('Name'), { target: { value: 'Test User' } });
    fireEvent.change(getByLabelText('Email'), { target: { value: 'test@example.com' } });
    fireEvent.change(getByLabelText('Password'), { target: { value: 'password123' } });
    fireEvent.change(getByLabelText('Confirm password'), { target: { value: 'password123' } });

    // Submit the form
    fireEvent.submit(getByText('SignUp'));

    // Ensure createUser was called with the correct user object
    await waitFor(() => {
      expect(mockCreateUser).toHaveBeenCalledWith({
        name: 'Test User',
        email: 'test@example.com',
        password: 'password123',
      });
    });

    // Ensure loginUser was called with the correct user object
    await waitFor(() => {
      expect(mockLoginUser).toHaveBeenCalledWith({ email: 'test@example.com', name: 'Test User' });
    });
  });

  it('displays validation errors on form submission', async () => {
    const { getByLabelText, getByText } = render(<SignUp loginUser={mockLoginUser} />);

    // Submit the form without filling in any fields
    fireEvent.submit(getByText('SignUp'));

    // Ensure validation error messages are displayed
    expect(getByText('Name is required.')).toBeInTheDocument();
    expect(getByText('Email is required.')).toBeInTheDocument();
    expect(getByText('Password is required.')).toBeInTheDocument();
    expect(getByText('Passwords do not match.')).toBeInTheDocument();
  });

  // Add more tests to cover other validation scenarios...
});
