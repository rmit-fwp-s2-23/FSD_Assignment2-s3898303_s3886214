import React from 'react';
import { render, fireEvent, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect'; // For custom matchers like toHaveTextContent
import SignIn from './SignIn'; // Update the import path accordingly

// Mock the loginUser function and verifyUser function
const mockLoginUser = jest.fn();
const mockVerifyUser = jest.fn();

jest.mock('../data/repository', () => ({
  verifyUser: (email, password) => mockVerifyUser(email, password),
}));

describe('SignIn Component', () => {
  it('renders the SignIn form', () => {
    const { getByText, getByLabelText } = render(<SignIn loginUser={mockLoginUser} />);
    
    // Verify that the form elements are present
    expect(getByText('SignIn')).toBeInTheDocument();
    expect(getByLabelText('Email')).toBeInTheDocument();
    expect(getByLabelText('Password')).toBeInTheDocument();
  });

  it('handles form submission and loginUser', async () => {
    mockVerifyUser.mockResolvedValueOnce({ email: 'test@example.com', name: 'Test User' });

    const { getByLabelText, getByText } = render(<SignIn loginUser={mockLoginUser} />);

    // Fill in the email and password fields
    fireEvent.change(getByLabelText('Email'), { target: { value: 'test@example.com' } });
    fireEvent.change(getByLabelText('Password'), { target: { value: 'password123' } });

    // Submit the form
    fireEvent.submit(getByText('SignIn'));

    // Ensure verifyUser was called with the correct values
    await waitFor(() => {
      expect(mockVerifyUser).toHaveBeenCalledWith('test@example.com', 'password123');
    });

    // Ensure loginUser was called with the correct user object
    await waitFor(() => {
      expect(mockLoginUser).toHaveBeenCalledWith({ email: 'test@example.com', name: 'Test User' });
    });
  });

  it('displays an error message on login failure', async () => {
    mockVerifyUser.mockResolvedValueOnce(null);

    const { getByLabelText, getByText } = render(<SignIn loginUser={mockLoginUser} />);

    // Fill in the email and password fields
    fireEvent.change(getByLabelText('Email'), { target: { value: 'test@example.com' } });
    fireEvent.change(getByLabelText('Password'), { target: { value: 'invalidpassword' } });

    // Submit the form
    fireEvent.submit(getByText('SignIn'));

    // Ensure verifyUser was called with the correct values
    await waitFor(() => {
      expect(mockVerifyUser).toHaveBeenCalledWith('test@example.com', 'invalidpassword');
    });

    // Ensure an error message is displayed
    expect(getByText('Email and/or password invalid, please try again.')).toBeInTheDocument();
  });
});
