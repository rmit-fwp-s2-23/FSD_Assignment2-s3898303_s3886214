/*Kaiyan (s3898303), Moosa (s3898303)*/
/*review.controller.js */

const db = require("../database"); // Import your database module

// Function to retrieve all reviews from the database.
exports.all = async (req, res) => {
  try {
    const review = await db.review.findAll(); // Fetch all reviews from the database
    res.json(review); // Respond with a JSON array containing review data
  } catch (err) {
    res.status(500).json({ message: "An error occurred while fetching reviews.", error: err.message });
    // Respond with a 500 status and an error message if an error occurs during the fetch
  }
};

// Function to create a new review in the database.
exports.create = async (req, res) => {
  try {
    // Ensure you validate the rating value before saving it to the database.
    // For instance, ensure it's an integer and within a specific range (e.g., 1-5).
    const review = await db.review.create({
      text: req.body.text,
      email: req.body.email, 
      rating: req.body.rating,
      movie: req.body.movie
    });
    res.status(201).json(review);
    // Create a new review in the database and respond with a 201 status (created) and the review data
  } catch (err) {
    res.status(500).json({ message: "An error occurred while creating the review.", error: err.message });
    // Respond with a 500 status and an error message if an error occurs during the creation
  }
};

// Function to update an existing review in the database.
exports.update = async (req, res) => {
  try {
    const reviewId = req.params.id; // Assuming you're passing the review ID in the route as a parameter.

    // Find the review by its ID
    const review = await db.review.findByPk(reviewId);
    
    if (!review) {
      return res.status(404).json({ message: "Review not found." });
      // Respond with a 404 status and a message if the review is not found
    }

    // Update the review with the data from the request body
    review.text = req.body.text;
    review.rating = req.body.rating;
    review.movie = req.body.movie;
    await review.save();

    res.json({ message: "Review updated successfully.", review: review });
    // Respond with a success message and the updated review data
  } catch (err) {
    res.status(500).json({ message: "An error occurred while updating the review.", error: err.message });
    // Respond with a 500 status and an error message if an error occurs during the update
  }
};

// Function to delete a review from the database.
exports.delete = async (req, res) => {
  try {
    const reviewId = req.params.id; // Assuming you're passing the review ID in the route as a parameter.

    // Find the review by its ID
    const review = await db.review.findByPk(reviewId);
    
    if (!review) {
      return res.status(404).json({ message: "Review not found." });
      // Respond with a 404 status and a message if the review is not found
    }

    // Delete the review from the database
    await review.destroy();

    res.json({ message: "Review deleted successfully." });
    // Respond with a success message
  } catch (err) {
    res.status(500).json({ message: "An error occurred while deleting the review.", error: err.message });
    // Respond with a 500 status and an error message if an error occurs during the deletion
  }
};
