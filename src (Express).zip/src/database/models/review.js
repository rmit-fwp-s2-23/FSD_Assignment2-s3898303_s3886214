/*Kaiyan (s3898303), Moosa (s3898303)*/
/* review.js */

module.exports = (sequelize, DataTypes) =>
  sequelize.define("review", {
    review_id: {
      type: DataTypes.INTEGER, // Define a field for the review ID
      autoIncrement: true, // Enable auto-increment for this field
      primaryKey: true // Set it as the primary key
    },
    text: {
      type: DataTypes.TEXT, // Define a field for the review text
      allowNull: false // Ensure the review text is a required field (not null)
    },
    rating: {
      type: DataTypes.INTEGER, // Define a field for the review rating
      allowNull: true, // Allow the rating to be optional (null)
      validate: {
        min: 1, // Specify a minimum value for the rating (you can adjust this)
        max: 5 // Specify a maximum value for the rating (you can adjust this)
      }
    },
    movie: {
      type: DataTypes.STRING, // Define a field for the movie title
      allowNull: false // Ensure the movie title is a required field (not null)
    },
  }, {
    // Configuration options for the model
    // Disable the timestamp attributes (updatedAt, createdAt).
    timestamps: false
  });
