/*Kaiyan (s3898303), Moosa (s3898303)*/
/* config.js */

/* insert your database credentials here*/

module.exports = {
  HOST: "rmit.australiaeast.cloudapp.azure.com",
  USER: "s3898303_fwp_a2",
  PASSWORD: "abc123",
  DB: "s3898303_fwp_a2",
  DIALECT: "mysql"
};
