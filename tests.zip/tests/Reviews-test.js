import React from 'react';
import { render, fireEvent, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect'; // For custom matchers like toHaveTextContent
import Forum from './Forum'; // Update the import path accordingly

// Mock the functions from your repository
const mockGetReviews = jest.fn();
const mockCreateReview = jest.fn();
const mockEditReview = jest.fn();
const mockDeleteReview = jest.fn();

jest.mock('../data/repository', () => ({
  getReviews: mockGetReviews,
  createReview: mockCreateReview,
  editReview: mockEditReview,
  deleteReview: mockDeleteReview,
}));

describe('Forum Component', () => {
  const user = { email: 'test@example.com' };

  beforeEach(() => {
    // Reset mock function calls before each test
    jest.clearAllMocks();
  });

  it('renders the form and reviews', () => {
    const { getByText } = render(<Forum user={user} />);
    
    // Verify that the form elements and reviews are present
    expect(getByText('Leave a Review')).toBeInTheDocument();
    // Add more assertions as needed based on your component's structure
  });

  it('handles review submission', async () => {
    const { getByLabelText, getByText } = render(<Forum user={user} />);
    const selectedMovie = 'Test Movie';
    const rating = '5';
    const reviewText = 'This is a test review.';

    // Fill out the form fields
    fireEvent.change(getByLabelText('Select Movie:'), { target: { value: selectedMovie } });
    fireEvent.change(getByLabelText('Rating:'), { target: { value: rating } });
    fireEvent.change(getByLabelText('Quill Editor'), { target: { value: reviewText } });

    // Submit the review
    fireEvent.click(getByText('Post Review'));

    // Ensure createReview was called with the correct parameters
    await waitFor(() => {
      expect(mockCreateReview).toHaveBeenCalledWith({
        text: reviewText,
        email: user.email,
        movie: selectedMovie,
        rating: rating,
      });
    });
  });

  it('handles review editing and deletion', async () => {
    // Mock reviews data
    const mockReviews = [
      {
        review_id: 1,
        text: 'Test Review 1',
        email: user.email,
        movie: 'Test Movie 1',
        rating: '5',
      },
      {
        review_id: 2,
        text: 'Test Review 2',
        email: 'other@example.com',
        movie: 'Test Movie 2',
        rating: '4',
      },
    ];

    // Mock the getReviews function to return the reviews
    mockGetReviews.mockResolvedValue(mockReviews);

    const { getByText } = render(<Forum user={user} />);

    // Edit a review (assuming there is a button to edit a review for user.email)
    fireEvent.click(getByText('Edit'));

    // Ensure the review editing UI is displayed

    // Simulate editing a review and saving it
    const editedReviewText = 'Edited Test Review';
    fireEvent.change(getByLabelText('Quill Editor'), { target: { value: editedReviewText } });
    fireEvent.click(getByText('Save Review'));

    // Ensure editReview was called with the correct parameters
    await waitFor(() => {
      expect(mockEditReview).toHaveBeenCalledWith(1, { text: editedReviewText });
    });

    // Delete a review (assuming there is a button to delete a review for user.email)
    fireEvent.click(getByText('Delete'));

    // Ensure deleteReview was called with the correct parameters
    await waitFor(() => {
      expect(mockDeleteReview).toHaveBeenCalledWith(1);
    });
  });
});
