import React from 'react';
import { render, screen } from '@testing-library/react';
import Navbar from './Navbar';

describe('Navbar Component', () => {
  it('renders the Navbar component', () => {
    render(<Navbar user={null} />);
    
    // Check if the navbar elements are rendered
    expect(screen.getByText('Loop Web')).toBeInTheDocument();
    expect(screen.getByText('Home')).toBeInTheDocument();
  });

  it('displays user-specific links when a user is authenticated', () => {
    const user = { name: 'John' };
    render(<Navbar user={user} />);
    
    // Check if user-specific links are rendered
    expect(screen.getByText('My Profile')).toBeInTheDocument();
    expect(screen.getByText('Movies')).toBeInTheDocument();
    expect(screen.getByText('Reviews')).toBeInTheDocument();
    expect(screen.getByText('Welcome, John')).toBeInTheDocument();
    expect(screen.getByText('Logout')).toBeInTheDocument();
  });

  it('displays public links when a user is not authenticated', () => {
    render(<Navbar user={null}></Navbar>);
    
    // Check if public links are rendered
    expect(screen.getByText('About Us')).toBeInTheDocument();
    expect(screen.getByText('SignUp')).toBeInTheDocument();
    expect(screen.getByText('SignIn')).toBeInTheDocument();
    expect(screen.getByText('Reviews')).toBeInTheDocument();
  });
});
