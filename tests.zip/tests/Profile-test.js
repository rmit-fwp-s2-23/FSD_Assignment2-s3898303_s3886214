import React from 'react';
import { render, fireEvent, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect'; // For custom matchers like toHaveTextContent
import MyProfile from './MyProfile'; // Update the import path accordingly

// Mock the editUser, deleteUser, and removeUser functions
const mockEditUser = jest.fn();
const mockDeleteUser = jest.fn();
const mockRemoveUser = jest.fn();

jest.mock('../data/repository', () => ({
  editUser: (email, name) => mockEditUser(email, name),
  deleteUser: (email) => mockDeleteUser(email),
  removeUser: () => mockRemoveUser(),
}));

describe('MyProfile Component', () => {
  const user = { email: 'test@example.com', name: 'Test User' };
  const logoutUser = jest.fn();

  it('renders the user profile', () => {
    const { getByText } = render(<MyProfile user={user} logoutUser={logoutUser} />);
    
    // Verify that the user profile elements are present
    expect(getByText('User Profile')).toBeInTheDocument();
    expect(getByText('Email:')).toBeInTheDocument();
    expect(getByText('Email:').nextSibling).toHaveTextContent(user.email);
    expect(getByText('Name:')).toBeInTheDocument();
    expect(getByText('Name:').nextSibling).toHaveTextContent(user.name);
    expect(getByText('Edit Profile')).toBeInTheDocument();
    expect(getByText('Delete Account')).toBeInTheDocument();
  });

  it('handles edit mode and updates user name', async () => {
    const { getByText, getByRole } = render(<MyProfile user={user} logoutUser={logoutUser} />);

    // Click the "Edit Profile" button
    fireEvent.click(getByText('Edit Profile'));

    // Input a new name and click the "Save" button
    const newName = 'New Name';
    fireEvent.change(getByRole('textbox'), { target: { value: newName } });
    fireEvent.click(getByText('Save'));

    // Ensure editUser was called with the correct parameters
    await waitFor(() => {
      expect(mockEditUser).toHaveBeenCalledWith(user.email, newName);
    });
  });

  it('handles delete account', async () => {
    const { getByText } = render(<MyProfile user={user} logoutUser={logoutUser} />);

    // Click the "Delete Account" button
    fireEvent.click(getByText('Delete Account'));

    // Ensure deleteUser and removeUser were called
    await waitFor(() => {
      expect(mockDeleteUser).toHaveBeenCalledWith(user.email);
      expect(mockRemoveUser).toHaveBeenCalled();
    });

    // Ensure logoutUser was called
    expect(logoutUser).toHaveBeenCalled();
  });
});
