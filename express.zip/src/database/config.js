module.exports = {
  HOST: "rmit.australiaeast.cloudapp.azure.com",
  USER: "s3886214_fwp_a2",
  PASSWORD: "abc123",
  DB: "s3886214_fwp_a2",
  DIALECT: "mysql"
};
