// models/reservation.js

module.exports = (sequelize, DataTypes) => {
    return sequelize.define("reservation", {
      reservationId: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
      },
      sessionTime: {
        type: DataTypes.STRING(5), // HH:MM format
        allowNull: false
      },
      seats: {
        type: DataTypes.INTEGER,
        allowNull: false,
        validate: {
          min: 1,
          max: 10
        }
      }
    }, {
      timestamps: true // CreatedAt and UpdatedAt are usually useful for reservations
    });
  };
  