const db = require("../database");

// Select all review from the database.
exports.all = async (req, res) => {
  try {
    const review = await db.review.findAll();
    res.json(review);
  } catch (err) {
    res.status(500).json({ message: "An error occurred while fetching reviews.", error: err.message });
  }
};

// Create a review in the database.
exports.create = async (req, res) => {
  try {
    // Ensure you validate the rating value before saving to the database.
    // For instance, ensure it's an integer and within a specific range (e.g., 1-5).
    const review = await db.review.create({
      text: req.body.text,
      email: req.body.email, 
      rating: req.body.rating,
      movie: req.body.movie
    });
    res.status(201).json(review);
  } catch (err) {
    res.status(500).json({ message: "An error occurred while creating the review.", error: err.message });
  }
};

// Update a review in the database.
exports.update = async (req, res) => {
  try {
    const reviewId = req.params.id; // Assuming you're passing the review ID in the route as a parameter.

    // Find the review by its ID
    const review = await db.review.findByPk(reviewId);
    
    if (!review) {
      return res.status(404).json({ message: "Review not found." });
    }

    // Update the review
    review.text = req.body.text;
    review.rating = req.body.rating;
    review.movie = req.body.movie;
    await review.save();

    res.json({ message: "Review updated successfully.", review: review });
  } catch (err) {
    res.status(500).json({ message: "An error occurred while updating the review.", error: err.message });
  }
};

// Delete a review from the database.
exports.delete = async (req, res) => {
  try {
    const reviewId = req.params.id; // Assuming you're passing the review ID in the route as a parameter.

    // Find the review by its ID
    const review = await db.review.findByPk(reviewId);
    
    if (!review) {
      return res.status(404).json({ message: "Review not found." });
    }

    // Delete the review
    await review.destroy();

    res.json({ message: "Review deleted successfully." });
  } catch (err) {
    res.status(500).json({ message: "An error occurred while deleting the review.", error: err.message });
  }
};