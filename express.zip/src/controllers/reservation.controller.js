const db = require("../database");

// Select all reservations from the database.
exports.all = async (req, res) => {
  try {
    const reservations = await db.reservation.findAll();
    res.json(reservations);
  } catch (err) {
    res.status(500).json({ message: "An error occurred while fetching reservations.", error: err.message });
  }
};

// Create a reservation in the database.
exports.create = async (req, res) => {
  try {
    // Validate sessionTime and seats here before creating the reservation.

    const reservation = await db.reservation.create({
      movieId: req.body.movieId,
      sessionTime: req.body.sessionTime,
      seats: req.body.seats,
      email: req.body.email,
      // Add user_id if you're associating reservations with users
    });
    res.status(201).json(reservation);
  } catch (err) {
    res.status(500).json({ message: "An error occurred while creating the reservation.", error: err.message });
  }
};

// Update a reservation in the database.
exports.update = async (req, res) => {
  try {
    const reservationId = req.params.id;

    const reservation = await db.reservation.findByPk(reservationId);
    
    if (!reservation) {
      return res.status(404).json({ message: "Reservation not found." });
    }

    // Validate sessionTime and seats here before updating the reservation.

    reservation.movieId = req.body.movieId;
    reservation.sessionTime = req.body.sessionTime;
    reservation.seats = req.body.seats;
    
    await reservation.save();

    res.json({ message: "Reservation updated successfully.", reservation: reservation });
  } catch (err) {
    res.status(500).json({ message: "An error occurred while updating the reservation.", error: err.message });
  }
};

// Delete a reservation from the database.
exports.delete = async (req, res) => {
  try {
    const reservationId = req.params.id;

    const reservation = await db.reservation.findByPk(reservationId);
    
    if (!reservation) {
      return res.status(404).json({ message: "Reservation not found." });
    }

    // You can implement authorization checks here to ensure the user can delete the reservation.

    await reservation.destroy();

    res.json({ message: "Reservation deleted successfully." });
  } catch (err) {
    res.status(500).json({ message: "An error occurred while deleting the reservation.", error: err.message });
  }
};
