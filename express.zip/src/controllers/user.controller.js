const db = require("../database");
const argon2 = require("argon2");

exports.all = async (req, res) => {
  const users = await db.user.findAll();
  res.json(users);
};

exports.one = async (req, res) => {
  const user = await db.user.findByPk(req.params.id);
  res.json(user);
};

exports.login = async (req, res) => {
  const user = await db.user.findOne({
    where: { email: req.body.email }
  });
  
  if (!user || !(await argon2.verify(user.password_hash, req.body.password))) {
    res.json(null);
  } else {
    res.json(user);
  }
};

exports.create = async (req, res) => {
  const hash = await argon2.hash(req.body.password, { type: argon2.argon2id });

  const user = await db.user.create({
    email: req.body.email,
    password_hash: hash,
    name: req.body.name
  });

  res.json(user);
}

exports.update = async (req, res) => {
  const email = req.params.email;

  const userToUpdate = {
    name: req.body.name
  };

  try {
    const user = await db.user.findOne({ where: { email } });
    if (!user) {
      return res.status(404).json({ message: "User not found!" });
    }
    await user.update(userToUpdate);
    res.json({ message: "User updated successfully." });
  } catch (error) {
    res.status(500).json({ message: "Error updating the user." });
  }
};

exports.delete = async (req, res) => {
  const email = req.params.email;
  
  try {
    const user = await db.user.findOne({ where: { email } });
    if (!user) {
      return res.status(404).json({ message: "User not found!" });
    }
    await user.destroy();
    res.json({ message: "User deleted successfully." });
  } catch (error) {
    res.status(500).json({ message: "Error deleting the user." });
  }
};
