/*Kaiyan (s3898303), Moosa (s3898303)*/
/* MyProfile.test.js */

import React from "react";
import { render, fireEvent, waitFor } from "@testing-library/react";
import MyProfile from "./MyProfile";
import { useNavigate } from "react-router-dom";
import { editUser, deleteUser, removeUser } from "../data/repository";

// Mocking navigate
jest.mock('react-router-dom', () => ({
  ...jest.requireActual('react-router-dom'),
  useNavigate: jest.fn()
}));

// Mocking repository functions
jest.mock("../data/repository", () => ({
  deleteUser: jest.fn(),
  removeUser: jest.fn()
}));

const mockLogout = jest.fn();
const mockNavigate = jest.fn();

describe("MyProfile Component", () => {
  beforeEach(() => {
    useNavigate.mockImplementation(() => mockNavigate);
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  describe("Deleting profile", () => {
    it("allows deleting the profile", async () => {
      // Create a user object for testing
      const user = {
        name: "John Doe",
        email: "john@example.com"
      };

      // Render the MyProfile component with the test user and mockLogout function
      const { getByText } = render(<MyProfile user={user} logoutUser={mockLogout} />);

      // Trigger Delete Account
      const deleteButton = getByText(/Delete Account/i);
      fireEvent.click(deleteButton);

      // Mock the deleteUser function to resolve immediately
      deleteUser.mockResolvedValueOnce(true);

      // Wait for deleteUser and removeUser to be called and actions to be verified
      await waitFor(() => {
        expect(deleteUser).toHaveBeenCalledWith(user.email);
        expect(removeUser).toHaveBeenCalled();
        expect(mockLogout).toHaveBeenCalled();
        expect(mockNavigate).toHaveBeenCalledWith("/");
      });
    });
  });
});
