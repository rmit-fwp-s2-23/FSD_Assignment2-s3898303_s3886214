import React from 'react';
import ImageCarousel from '../components/ImageCarousel';
import '../style/Home.css';
import movieImage from '../assets/Spider.jpg';

export const movies = [
  {
    title: 'The Revenge of Spiderman',
    image: require('../assets/Spider.jpg'),
  },
  {
    title: 'Fire Wrecks a Forrest',
    image: require('../assets/Fire.jpg'),
  },
  {
    title: 'Love the Classic Way',
    image: require('../assets/Love.jpg'),
  },
];

export default function Home(props) {
  return (
    <div className="home-container">
      
      {/* User greeting */}
      {props.user !== null && (
        <h4 className="user-greeting">
          <strong>Hello {props.user.first_name} {props.user.last_name}!</strong>
        </h4>
      )}

      <div className="hero-section">
        <h1 className="hero-title">Discover the Magic of Cinema</h1>
        <p className="hero-subtitle">
          Explore the Latest Blockbusters and Unforgettable Classics.
        </p>
        <p className="hero-subtitle">
          Experience the World of Movies Like Never Before!
        </p>
      </div>

      <ImageCarousel
        header="Now Playing"
        images={[movieImage, movieImage, movieImage]}
        content="Experience the excitement of the big screen with our latest movie releases. From thrilling action-packed adventures to heartwarming dramas, we have a movie for every mood."
      />
      
      {/* You can include other features from the example home here, such as the logo. */}
    </div>
  );
}
