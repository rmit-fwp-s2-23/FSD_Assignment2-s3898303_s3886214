/*Kaiyan (s3898303), Moosa (s3898303)*/
/* SignIn.js */

import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { verifyUser } from "../data/repository"; // Import a function for user verification

// Create and export a functional component named "SignIn" that receives props.
export default function SignIn(props) {
  const navigate = useNavigate(); // React Router's navigation function for page redirection
  const [fields, setFields] = useState({ email: "", password: "" }); // State to manage email and password fields
  const [errorMessage, setErrorMessage] = useState(null); // State to display error messages

  // Generic change handler to update state with input values.
  const handleInputChange = (event) => {
    setFields({ ...fields, [event.target.name]: event.target.value });
  };

  // Function to handle form submission (Sign In)
  const handleSubmit = async (event) => {
    event.preventDefault();

    // Call the verifyUser function to authenticate the user.
    const user = await verifyUser(fields.email, fields.password);

    if (user === null) {
      // Login failed, reset password field to blank and set an error message.
      setFields({ ...fields, email: "", password: "" });
      setErrorMessage("Email and/or password invalid, please try again.");
      return;
    }

    // Set user state via the props passed to the component (likely for application-wide user management).
    props.loginUser(user);

    // Navigate to the home page.
    navigate("/");
  };

  return (
    <div className="signup-container">
      <div className="signup-form">
        <h1>SignIn</h1>
        <hr />
        <form onSubmit={handleSubmit}>
          {/* Email Field */}
          <div className="form-group">
            <label htmlFor="email" className="control-label">
              Email
            </label>
            <input
              name="email"
              id="email"
              className="form-control"
              value={fields.email}
              onChange={handleInputChange}
            />
          </div>
          {/* Password Field */}
          <div className="form-group">
            <label htmlFor="password" className="control-label">
              Password
            </label>
            <input
              type="password"
              name="password"
              id="password"
              className="form-control"
              value={fields.password}
              onChange={handleInputChange}
            />
          </div>
          {/* SignIn Button */}
          <div className="form-group">
            <input type="submit" className="signup-button" value="SignIn" />
          </div>
          {errorMessage !== null && (
            <div className="form-group">
              <span className="text-danger">{errorMessage}</span>
            </div>
          )}
        </form>
      </div>
    </div>
  );
}
