/*Kaiyan (s3898303), Moosa (s3898303)*/
/* Movies.js */
// Import React and useState hook from the 'react' library
import React, { useState } from 'react';

// Import the associated CSS file for styling
import '../style/Movies.css';

// Import movie images directly from the asset files
import SpiderImage from '../assets/Spider.jpg';
import FireImage from '../assets/Fire.jpg';
import LoveImage from '../assets/Love.jpg';

// Create an object that maps movie titles to their respective image imports
const movieImages = {
  'The Revenge of Spiderman': SpiderImage,
  'Fire Wrecks a Forrest': FireImage,
  'Love the Classic Way': LoveImage,
  // You can add more images here as needed for additional movies
};

// Create a functional component named Movies
const Movies = () => {
  // Initialize the 'movies' state using the 'useState' hook
  const [movies, setMovies] = useState([
    {
      id: 1,
      title: 'The Revenge of Spiderman',
      description: 'In "The Revenge of Spiderman," our friendly neighborhood superhero, Spiderman, faces his greatest challenge yet. When a new supervillain emerges, seeking revenge for a past incident, Spiderman must rely on his wit, agility, and web-slinging abilities to protect the city and those he cares about. Get ready for an action-packed adventure that will keep you on the edge of your seat!',
    },
    {
      id: 2,
      title: 'Fire Wrecks a Forrest',
      description: 'In "Fire Wrecks a Forrest," a peaceful forest community finds itself in grave danger when a massive fire breaks out and threatens to consume everything in its path. As the flames spread rapidly, a group of firefighters and local residents must band together to fight the inferno and save their homes. This gripping tale of courage, sacrifice, and survival will take you through a rollercoaster of emotions.',
    },
    {
      id: 3,
      title: 'Love the Classic Way',
      description: 'Get ready for a heartwarming journey in "Love the Classic Way." This romantic drama follows the lives of two individuals from different walks of life who unexpectedly cross paths. As they navigate the challenges of modern dating and technology, they discover the timeless power of genuine connection and the magic of falling in love the old-fashioned way. Join them on this enchanting ride full of laughter, tears, and heartfelt moments.',
    },
    // You can add more movie objects here as needed
  ]);

  return (
    <div>
      {/* Display the main heading for the movie list */}
      <h2>Movie List</h2>

      {/* Map over the 'movies' state and render each movie */}
      {movies.map((movie) => (
        // Create a div for each movie with a unique 'key' attribute
        <div key={movie.id} className="movie">
          {/* Display the movie title */}
          <h3>{movie.title}</h3>

          {/* Display the movie image using the corresponding image from 'movieImages' */}
          <img
            src={movieImages[movie.title]} // Use the image corresponding to the movie title
            alt={movie.title} // Set the alt text for accessibility
          />

          {/* Display the movie description */}
          <p>{movie.description}</p>
        </div>
      ))}
    </div>
  );
};

// Export the Movies component to be used in other parts of the application
export default Movies;
