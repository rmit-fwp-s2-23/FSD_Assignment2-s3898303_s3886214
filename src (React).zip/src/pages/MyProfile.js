/*Kaiyan (s3898303), Moosa (s3898303)*/
/* MyProfile.js */

import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { editUser, deleteUser, removeUser } from "../data/repository";
import '../style/UserProfile.css'; // Import your CSS file

// Define a functional component named "MyProfile" that receives props.
export default function MyProfile(props) {
  const [name, setName] = useState(props.user.name); // Initialize state for the user's name
  const [isEditing, setIsEditing] = useState(false); // Initialize state for editing mode
  const navigate = useNavigate(); // Access the router's navigate function for navigation

  const handleNameChange = (event) => {
    setName(event.target.value); // Update the name in the state when input changes
  };

  const handleEditClick = () => {
    setIsEditing(true); // Enable editing mode
  };

  const handleCancelClick = () => {
    setIsEditing(false); // Disable editing mode
    setName(props.user.name); // Reset name changes to the original value
  };

  const handleSaveClick = async () => {
    await editUser(props.user.email, name); // Save the edited name to the server
    setIsEditing(false); // Disable editing mode
  };

  const handleDelete = async () => {
    await deleteUser(props.user.email); // Delete the user's account on the server
    removeUser(); // Remove user data from local storage
    props.logoutUser(); // Trigger the logout function
    navigate("/"); // Navigate to the home page
  };

  return (
    <div className="profile-container">
      <h2>User Profile</h2>
      <div className="profile-section">
        <p className="profile-label">Email:</p>
        <p className="profile-value">{props.user.email}</p>
      </div>
      <div className="profile-section">
        <p className="profile-label">Name:</p>
        {isEditing ? ( // Conditionally render input for name editing
          <input
            type="text"
            value={name}
            onChange={handleNameChange}
            className="profile-input"
          />
        ) : (
          <p className="profile-value">{name}</p> // Display the user's name or input for editing
        )}
      </div>
      <div className="profile-button-group">
        {isEditing ? ( // Conditionally render buttons for saving and canceling edits
          <>
            <button onClick={handleSaveClick} className="profile-button save-button">Save</button>
            <button onClick={handleCancelClick} className="profile-button cancel-button">Cancel</button>
          </>
        ) : ( // Conditionally render buttons for editing and deleting the account
          <>
            <button onClick={handleEditClick} className="profile-button edit-button">Edit Profile</button>
            <button onClick={handleDelete} className="profile-button delete-button">Delete Account</button>
          </>
        )}
      </div>
    </div>
  );
}
