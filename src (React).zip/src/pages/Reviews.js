/*Kaiyan (s3898303), Moosa (s3898303)*/
/* Reviews.js */

import React, { useState, useEffect } from "react";
import ReactQuill from "react-quill";
import "react-quill/dist/quill.snow.css"; // Import styles for the ReactQuill editor
import '../style/Reviews.css'; // Import your custom CSS file for styling
import { getReviews, createReview, editReview, deleteReview } from "../data/repository"; // Import functions for interacting with reviews
import { movies } from './Home'; // Import a list of movies
import SpiderImage from '../assets/Spider.jpg'; // Import images for movies
import FireImage from '../assets/Fire.jpg';
import LoveImage from '../assets/Love.jpg';

// Define an object that maps movie titles to their respective images
const movieImages = {
  'The Revenge of Spiderman': SpiderImage,
  'Fire Wrecks a Forrest': FireImage,
  'Love the Classic Way': LoveImage,
};

// Create and export a functional component named "Forum" that receives props.
export default function Forum(props) {
  const [review, setReview] = useState(""); // State for the review content
  const [editingReviewId, setEditingReviewId] = useState(null); // State to track the currently edited review
  const [selectedMovie, setSelectedMovie] = useState(""); // State to select a movie for the review
  const [rating, setRating] = useState(""); // State to select a rating for the review
  const [errorMessage, setErrorMessage] = useState(null); // State to display error messages
  const [isLoading, setIsLoading] = useState(true); // State to track loading status
  const [reviews, setReviews] = useState([]); // State to store the list of reviews

  // Use the useEffect hook to load reviews when the component mounts
  useEffect(() => {
    async function loadReviews() {
      const currentReviews = await getReviews();
      setReviews(currentReviews);
      setIsLoading(false);
    }
    loadReviews();
  }, []);

  // Function to reset the review content and editing state
  const resetReviewContent = () => {
    setReview("");
    setErrorMessage(null);
    setEditingReviewId(null);
  };

  // Function to handle the "Edit" button click
  const handleEdit = (reviewId, reviewText, reviewEmail) => {
    // Check if the review email matches the logged-in user's email
    if (props.user.email === reviewEmail) {
      setEditingReviewId(reviewId);
      setReview(reviewText);
    } else {
      alert("You can only edit your own reviews.");
    }
  };

  // Function to save an edited review
  const handleSaveEdit = async () => {
    if (editingReviewId) {
      const updatedReview = await editReview(editingReviewId, { text: review });
      // Ensure the structure is consistent, and update the review in the state
      const newReviewData = {
        ...updatedReview,
        text: review
      };
      const updatedReviews = reviews.map(r => r.review_id === editingReviewId ? newReviewData : r);
      setReviews(updatedReviews);
      resetReviewContent();
    }
  };

  // Function to calculate the average rating for a movie
  const calculateAverageRating = (movieTitle) => {
    const movieReviews = reviews.filter(review => review.movie === movieTitle);
    const totalRating = movieReviews.reduce((sum, review) => sum + parseInt(review.rating, 10), 0);
    const averageRating = movieReviews.length > 0 ? (totalRating / movieReviews.length).toFixed(1) : 0;
    return averageRating;
  };

  // Function to handle the "Delete" button click
  const handleDelete = async (reviewId, reviewEmail) => {
    // Check if the review email matches the logged-in user's email
    if (props.user.email === reviewEmail) {
      await deleteReview(reviewId);
      const updatedReviews = reviews.filter(r => r.review_id !== reviewId);
      setReviews(updatedReviews);
    } else {
      alert("You can only delete your own reviews.");
    }
  };

  // Function to handle the review submission
  const handleSubmit = async (event) => {
    event.preventDefault();

    // Validate that the review content is not empty
    if (review.replace(/<(.|\n)*?>/g, "").trim().length === 0) {
      setErrorMessage("A review cannot be empty.");
      return;
    }

    if (editingReviewId) {
      handleSaveEdit();
    } else {
      const newReview = {
        text: review,
        email: props.user.email,
        movie: selectedMovie,
        rating: rating
      };

      // Create a new review and update the state with the new review
      await createReview(newReview);
      setReviews([...reviews, newReview]);
      resetReviewContent();
    }
  };

  return (
    <div className="review-container">
      <h2>{editingReviewId ? "Edit Review" : "Leave a Review"}</h2>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="selectedMovie">Select Movie:</label>
          <select
            id="selectedMovie"
            name="selectedMovie"
            value={selectedMovie}
            onChange={e => setSelectedMovie(e.target.value)}
            required
          >
            <option value="">Select Movie</option>
            {movies.map((movie) => (
              <option key={movie.title} value={movie.title}>
                {movie.title}
              </option>
            ))}
          </select>
        </div>
        <div className="form-group">
          <label htmlFor="rating">Rating:</label>
          <select
            id="rating"
            name="rating"
            value={rating}
            onChange={e => setRating(e.target.value)}
            required
          >
            <option value="">Select Rating</option>
            <option value="5">5 stars</option>
            <option value="4">4 stars</option>
            <option value="3">3 stars</option>
            <option value="2">2 stars</option>
            <option value="1">1 star</option>
          </select>
        </div>

        {/* Display Movie Image */}
        {selectedMovie && (
          <div className="form-group">
            <img src={movieImages[selectedMovie]} alt={selectedMovie} width="150" height="200" />
          </div>
        )}

        {/* React Quill Editor */}
        <div className="form-group" style={{ marginBottom: "60px" }}>
          <ReactQuill theme="snow" value={review} onChange={setReview} style={{ height: "180px" }} />
        </div>

        {errorMessage && (
          <div className="form-group">
            <span className="text-danger">{errorMessage}</span>
          </div>
        )}

        <div className="form-group">
          <input type="button" className="btn btn-danger mr-5" value="Cancel" onClick={resetReviewContent} />
          <input type="submit" className="btn btn-primary" value={editingReviewId ? "Save Review" : "Post Review"} />
        </div>
      </form>

      <hr />
      <h1>Reviews</h1>
      <div>
        {isLoading ? (
          <div>Loading reviews...</div>
        ) : reviews.length === 0 ? (
          <span className="text-muted">No reviews have been submitted.</span>
        ) : (
          reviews.map((x) => (
            <div key={x.review_id} className="border my-3 p-3">
              <h6 className="text-primary">{x.email}</h6>
              <h6 className="text-secondary">Movie: {x.movie} - Rating: {x.rating} stars</h6>
              <div dangerouslySetInnerHTML={{ __html: x.text }} />
              {props.user.email === x.email && ( // Only show buttons if the user is the one who wrote the review
                <>
                  <button onClick={() => handleEdit(x.review_id, x.text, x.email)}>Edit</button>
                  <button onClick={() => handleDelete(x.review_id, x.email)}>Delete</button>
                </>
              )}
            </div>
          ))
        )}
      </div>

      <hr />
      <h1>Average Ratings</h1>
      <div className="average-ratings-container">
        {movies.map(movie => (
          <div key={movie.title} className="movie-rating">
            <img src={movieImages[movie.title]} alt={movie.title} width="150" height="200" />
            <div className="movie-title">{movie.title}</div>
            <div className="average-rating">Average Rating: {calculateAverageRating(movie.title)} stars</div>
          </div>
        ))}
      </div>
    </div>
  );
}
