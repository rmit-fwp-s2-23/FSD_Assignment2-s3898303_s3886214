/*Kaiyan (s3898303), Moosa (s3898303)*/
/* SignUp.test.js */

import React from 'react';
import { render, fireEvent } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import { MemoryRouter } from 'react-router-dom';
import SignUp from './SignUp';

describe('SignUp Component', () => {

  // Test for validating Name, Email, and Password inputs
  test('validates Name, Email, and Password inputs correctly', () => {
    const mockLoginUser = jest.fn();

    const { getByLabelText } = render(
      <MemoryRouter>
        <SignUp loginUser={mockLoginUser} />
      </MemoryRouter>
    );
    
    // Get input fields for Name, Email, and Password by their label text
    const nameInput = getByLabelText('Name');
    const emailInput = getByLabelText('Email');
    const passwordInput = getByLabelText(/Password/);

    // Simulate user input by changing the field values
    fireEvent.change(nameInput, { target: { value: 'John' } });
    fireEvent.change(emailInput, { target: { value: 'john@example.com' } });
    fireEvent.change(passwordInput, { target: { value: 'Password@123!' } });

    // Verify if the input values match the user input
    expect(nameInput.value).toBe('John');
    expect(emailInput.value).toBe('john@example.com');
    expect(passwordInput.value).toBe('Password@123!');
  });

  // Test for a valid email and an invalid password
  test('validates a valid email and an invalid password', () => { 
    const mockLoginUser = jest.fn();

    const { getByLabelText, getByRole, findByText } = render(
      <MemoryRouter>
        <SignUp loginUser={mockLoginUser} />
      </MemoryRouter>
    );

    // Get input fields for Name, Email, and Password, and the Sign Up button by their respective elements
    const nameInput = getByLabelText('Name');
    const emailInput = getByLabelText('Email');
    const passwordInput = getByLabelText(/Password/);
    const signUpButton = getByRole('button', { name: /SignUp/i }); // Use getByRole instead of getByText

    // Simulate user input by changing the field values and attempting to sign up
    fireEvent.change(nameInput, { target: { value: 'John' } });
    fireEvent.change(emailInput, { target: { value: 'john@example.com' } });
    fireEvent.change(passwordInput, { target: { value: 'password' } }); // Using a weak password
    fireEvent.click(signUpButton);

    // Use async/await and findByText to check for the error message
    return findByText(/Password must be at least 8 characters and include at least one lowercase letter, one uppercase letter, one digit, and one special character./i).then(errorMessage => {
      expect(errorMessage).toBeInTheDocument();
    });
  });

});
