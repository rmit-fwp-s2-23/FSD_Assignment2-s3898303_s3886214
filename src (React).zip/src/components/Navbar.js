/*Kaiyan (s3898303), Moosa (s3898303)*/
/* Navbar.js */

import React from "react";
import { Link } from "react-router-dom"; // Import the Link component from React Router for navigation.

// Define a functional component named "Navbar" that receives props.
export default function Navbar(props) {
  return (
    <nav className="navbar navbar-expand-lg navbar-dark bg-dark">
      <div className="container">
        <Link className="navbar-brand" to="/">Loop Web</Link> {/* Display the site logo with a link to the home page */}
        <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
          aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span className="navbar-toggler-icon"></span> {/* Toggle button for collapsed navigation menu */}
        </button>
        <div className="collapse navbar-collapse" id="navbarSupportedContent">
          <ul className="navbar-nav mr-auto">
            <li className="nav-item">
              <Link className="nav-link" to="/">Home</Link> {/* Navigation link to the home page */}
            </li>
            {props.user !== null && // Conditionally render links based on user authentication
              <>
                <li className="nav-item">
                  <Link className="nav-link" to="/profile">My Profile</Link> {/* Link to user's profile */}
                </li>
                <li className="nav-item">
                  <Link className="nav-link" to="/movies">Movies</Link> {/* Link to movies page */}
                </li>
                <li className="nav-item">
                  <Link className="nav-link" to="/forum">Reviews</Link> {/* Link to reviews or forum page */}
                </li>
              </>
            }
          </ul>
          <ul className="navbar-nav">
            {props.user === null ? // Conditionally render links and user greeting based on user authentication
              <>
               <li className="nav-item">
                  <Link className="nav-link" to="/about">About Us</Link> {/* Link to the about page */}
                </li>
                <li className="nav-item">
                  <Link className="nav-link" to="/register">SignUp</Link> {/* Link to registration page */}
                </li>
                <li className="nav-item">
                  <Link className="nav-link" to="/login">SignIn</Link> {/* Link to login page */}
                </li>
                <li className="nav-item">
                  <Link className="nav-link" to="/forum">Reviews</Link> {/* Link to reviews or forum page */}
                </li>
              </>
              :
              <>
                <li className="nav-item">
                  <span className="nav-link text-light">Welcome, {props.user.name}</span> {/* Display a welcome message with the user's name */}
                </li>
                <li className="nav-item">
                  <Link className="nav-link" to="/login" onClick={props.logoutUser}>Logout</Link> {/* Link to log out and trigger the logoutUser function on click */}
                </li>
              </>
            }
          </ul>
        </div>
      </div>
    </nav>
  );
}
