/*Kaiyan (s3898303), Moosa (s3898303)*/
/* ImageCarousel.js */
// Import React library to create React components
import React from 'react';

// Import the 'Carousel' component from the 'react-responsive-carousel' library
import { Carousel } from 'react-responsive-carousel';

// Import the CSS styles for the image carousel (import the CSS file you created)
import 'react-responsive-carousel/lib/styles/carousel.min.css';
import '../style/ImageCarousel.css';

// Define the 'ImageCarousel' component
const ImageCarousel = () => {
  const movies = [ // Export the movies array
  {
    title: 'The Revenge of Spiderman',
    image: require('../assets/Spider.jpg'),
    description: 'In Theatres 17th of November 2023',
  },
  {
    title: 'Fire Wrecks a Forrest',
    image: require('../assets/Fire.jpg'),
    description: 'In Theatres 19th of November 2023',
  },
  {
    title: 'Love the Classic Way',
    image: require('../assets/Love.jpg'),
    description: 'In Theatres 21th of November 2023',
  },
];

  return (
    // Create a container div with a class name 'image-carousel-container'
    <div className="image-carousel-container">
      {/* Create a 'Carousel' component for the image carousel */}
      <Carousel
        showThumbs={false} // Hide thumbnail images
        showStatus={false} // Hide status indicators
        autoPlay={true} // Enable auto-play
        infiniteLoop={true} // Enable infinite loop of images
        interval={2500} // Set interval between image transitions (milliseconds)
        transitionTime={500} // Set transition time for image animations (milliseconds)
        emulateTouch={true} // Emulate touch interactions for mobile devices
        swipeable={true} // Allow swipe gestures on touch devices
      >
        {/* Map through the 'movies' array and create carousel items for each movie */}
        {movies.map((movie, index) => (
          // Create a div for each carousel item with a unique key and class name 'carousel-item'
          <div key={index} className="carousel-item">
            {/* Display the movie image using the 'img' element with 'src' and 'alt' attributes */}
            <img src={movie.image} alt={movie.title} />
            
            {/* Create a div for movie details with class name 'movie-details' */}
            <div className="movie-details">
              {/* Display the movie title */}
              <h3 className="movie-title">{movie.title}</h3>
              
              {/* Display the movie description (Note: 'movie.description' is not available in the provided code) */}
              <p className="movie-description">{movie.description}</p>
            </div>
          </div>
        ))}
      </Carousel>
    </div>
  );
};

// Export the 'ImageCarousel' component to be used in other parts of the application
export default ImageCarousel;
